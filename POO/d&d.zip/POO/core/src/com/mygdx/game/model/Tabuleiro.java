package com.mygdx.game.model;

public class Tabuleiro {
	private int tamanho;
	private Casa[][] casas;
	private char[][] board = 
	{/* Escreve o tabuleiro */};
	public Casa[][] getCasas() {
		return casas;
	}
}
