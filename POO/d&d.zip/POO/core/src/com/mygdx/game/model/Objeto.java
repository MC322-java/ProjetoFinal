package com.mygdx.game.model;

public class Objeto extends Componente {
	
}
