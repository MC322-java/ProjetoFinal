package com.mygdx.game.model;

public class Bau extends Objeto {

}
