package com.mygdx.game.model;

public class Guerreiro extends Personagem {

	@Override
	public void atacar(Tabuleiro tabuleiro) {
		// fazer um ataque na casa da frente de acordo com a arma equipada
	}	
}
