package com.mygdx.game.model;

public class Componente {
	protected int linha;
	protected int coluna;
}
